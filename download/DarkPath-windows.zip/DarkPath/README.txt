Dark Path - campaign playtest build for Windows (64-bit), October 21, 2026

Run DarkPath.exe. There is no installer: unzip the folder anywhere and start the game.

Windows may say "Windows protected your PC" because the game is not signed.
Click "More info", then "Run anyway".

Needs a graphics card with OpenGL 3.3. Saves (autosave only) are kept in
%APPDATA%\Godot\app_userdata\Dark Path\

The whole campaign: the Prologue and four acts, each a countdown and an
invasion. At a new game, choose its length: Full (countdowns of 30, 30, 25
and 20 days) or Short (10, 10, 9 and 8).
Esc opens the menu; Settings has the controls, interface size, music,
first-time hints and colorblind-friendly health bars.

FEEDBACK: after every battle the game saves a short battle log in
%APPDATA%\Godot\app_userdata\Dark Path\battle_logs\
(the battle summary has a button that opens that folder). Please attach
those files when you report how it went:
https://github.com/mclianmalvar/darkpath/issues

Website: https://mclianmalvar.github.io/darkpath/
